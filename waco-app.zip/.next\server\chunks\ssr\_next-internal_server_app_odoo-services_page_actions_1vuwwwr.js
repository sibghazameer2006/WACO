module.exports=[14410,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_odoo-services_page_actions_1vuwwwr.js.map