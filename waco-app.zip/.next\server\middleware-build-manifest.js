globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/_IbVx_9DYR9ef7sIY_rU0/_buildManifest.js",
    "static/_IbVx_9DYR9ef7sIY_rU0/_ssgManifest.js",
    "static/_IbVx_9DYR9ef7sIY_rU0/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3yfl9fgvivx3-.js",
    "static/chunks/11jq0c2_zavac.js",
    "static/chunks/1mkbuudhndal5.js",
    "static/chunks/3jg84jwj6s1uj.js",
    "static/chunks/turbopack-3ns_9u_kzq326.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
