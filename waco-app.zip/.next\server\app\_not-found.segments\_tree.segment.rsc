:HL["/_next/static/chunks/07c03ikuao-79.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4112,"slots":{"children":{"name":"/_not-found","param":null,"prefetchHints":4160,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}},"staleTime":300,"buildId":"_IbVx_9DYR9ef7sIY_rU0"}
